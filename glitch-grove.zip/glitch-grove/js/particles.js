// js/particles.js
// Simple particle system for death explosions and goal celebrations

let particles = [];

/**
 * spawnParticles(x, y, color, count)
 * Burst of particles at a world position.
 */
function spawnParticles(x, y, color, count) {
  for (let i = 0; i < count; i++) {
    const angle = Math.random() * Math.PI * 2;
    const speed = 2 + Math.random() * 5;
    particles.push({
      x,
      y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed - 3,
      life: 1,
      color,
      r: 3 + Math.random() * 4,
    });
  }
}

/**
 * updateParticles(dt)
 * Advance all particles by one frame.
 */
function updateParticles(dt) {
  particles.forEach(p => {
    p.x    += p.vx * dt;
    p.y    += p.vy * dt;
    p.vy   += 0.2 * dt;
    p.life -= 0.04 * dt;
  });
  particles = particles.filter(p => p.life > 0);
}

/**
 * drawParticles(ctx)
 * Render all active particles.
 */
function drawParticles(ctx) {
  particles.forEach(p => {
    ctx.globalAlpha = p.life;
    ctx.fillStyle   = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r * p.life, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.globalAlpha = 1;
}

/**
 * clearParticles()
 * Remove all particles (called on level reset).
 */
function clearParticles() {
  particles = [];
}
