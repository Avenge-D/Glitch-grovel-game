// js/game.js
// Main game loop, physics, input, and rendering for Glitch Grove

// ─── Canvas Setup ────────────────────────────────────────────────────────────
const canvas = document.getElementById('gc');
const ctx    = canvas.getContext('2d');
const W = 680, H = 400;
canvas.width  = W;
canvas.height = H;
document.getElementById('wrap').style.height = H + 'px';
canvas.style.height = H + 'px';

// ─── Constants ───────────────────────────────────────────────────────────────
const GY   = 330;   // ground Y
const GRAV = 0.58;
const JSPD = -13;
const PSPD = 3.8;

// ─── State ───────────────────────────────────────────────────────────────────
let deaths    = 0;
let lvIdx     = 0;
let gameState = 'play'; // 'play' | 'dead' | 'win'
let facing    = 1;      // 1=right, -1=left
let screenFlash      = 0;
let screenFlashColor = '#ff0000';
let warnTimerLeft    = 0;

const keys = { left: false, right: false, jump: false };

function mkPlayer() {
  return { x: 55, y: GY - 28, vx: 0, vy: 0, w: 26, h: 26, onG: false, dead: false, jHeld: false, alpha: 1 };
}
let pl = mkPlayer();

// ─── Level data ──────────────────────────────────────────────────────────────
let allLevels = buildLevels();
let lv        = allLevels[0];

// ─── UI helpers ──────────────────────────────────────────────────────────────
function showMsg(text, duration = 2200) {
  const el = document.getElementById('msg');
  el.textContent = text;
  clearTimeout(el._t);
  el._t = setTimeout(() => (el.textContent = ''), duration);
}

function showWarn(text) {
  const el = document.getElementById('warn');
  el.textContent  = text;
  el.style.opacity = '1';
  warnTimerLeft = 900;
}

function hideWarn() {
  document.getElementById('warn').style.opacity = '0';
}

// ─── Background / Ground ─────────────────────────────────────────────────────
function drawBg() {
  ctx.fillStyle = '#0d0720';
  ctx.fillRect(0, 0, W, H);

  // Stars
  for (let i = 0; i < 50; i++) {
    const sx = (i * 137.5) % W;
    const sy = (i * 89.3)  % (H * 0.7);
    ctx.fillStyle = `rgba(255,255,255,${0.2 + ((i * 31) % 10) / 30})`;
    ctx.beginPath();
    ctx.arc(sx, sy, 0.8 + ((i * 17) % 3) * 0.4, 0, Math.PI * 2);
    ctx.fill();
  }

  // Moon
  ctx.fillStyle = '#ffe8a0';
  ctx.beginPath(); ctx.arc(580, 55, 22, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#0d0720';
  ctx.beginPath(); ctx.arc(588, 51, 17, 0, Math.PI * 2); ctx.fill();
}

function drawGround() {
  ctx.fillStyle = '#1a0f30';
  ctx.fillRect(0, GY, W, H - GY);
  ctx.fillStyle = '#5b21b6';
  ctx.fillRect(0, GY, W, 5);
  for (let i = 0; i < W; i += 22) {
    ctx.fillStyle = i % 44 === 0 ? '#7c3aed' : '#6d28d9';
    ctx.beginPath();
    ctx.moveTo(i, GY);
    ctx.quadraticCurveTo(i + 5, GY - 7, i + 11, GY);
    ctx.quadraticCurveTo(i + 16, GY - 4, i + 22, GY);
    ctx.fill();
  }
}

function drawGoal(g) {
  const t = Date.now() / 400;
  ctx.fillStyle = 'rgba(251,191,36,0.2)';
  ctx.beginPath(); ctx.arc(g.x, g.y, 26 + Math.sin(t) * 4, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#fbbf24';
  ctx.beginPath(); ctx.arc(g.x, g.y, 15, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 15px sans-serif';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText('★', g.x, g.y);
}

// ─── Death & Level Reset ─────────────────────────────────────────────────────
function die(color = '#e8a93a') {
  if (pl.dead || gameState !== 'play') return;
  pl.dead   = true;
  gameState = 'dead';
  deaths++;
  document.getElementById('dc').textContent = 'Deaths: ' + deaths;

  spawnParticles(pl.x + pl.w / 2, pl.y + pl.h / 2, color,   22);
  spawnParticles(pl.x + pl.w / 2, pl.y + pl.h / 2, '#c97c10', 10);

  screenFlash      = 1;
  screenFlashColor = color;

  const fadeInt = setInterval(() => {
    pl.alpha -= 0.12;
    if (pl.alpha <= 0) { pl.alpha = 0; clearInterval(fadeInt); }
  }, 30);

  setTimeout(() => resetLevel(lvIdx), 700);
}

function resetLevel(idx) {
  allLevels = buildLevels();
  lv        = allLevels[idx];
  pl        = mkPlayer();
  pl.y      = lv.groundY - pl.h;
  gameState = 'play';
  screenFlash = 0;
  facing    = 1;
  clearParticles();
  document.getElementById('lvl').textContent = 'Level ' + (idx + 1);
  showMsg(lv.msg, 2400);
}

// ─── Physics & Trap Logic ────────────────────────────────────────────────────
function update(dt) {
  if (gameState !== 'play') return;

  // Movement
  if (keys.left)       { pl.vx = -PSPD; facing = -1; }
  else if (keys.right) { pl.vx =  PSPD; facing =  1; }
  else                 { pl.vx *= 0.65; }

  // Jump
  if (keys.jump && pl.onG && !pl.jHeld) {
    pl.vy    = JSPD;
    pl.onG   = false;
    pl.jHeld = true;
  }
  if (!keys.jump) pl.jHeld = false;

  pl.vy += GRAV * dt;
  pl.x  += pl.vx * dt;
  pl.y  += pl.vy * dt;
  pl.onG = false;

  // Ground
  if (pl.y + pl.h >= lv.groundY) {
    pl.y  = lv.groundY - pl.h;
    pl.vy = 0;
    pl.onG = true;
  }

  // Wall clamp
  if (pl.x < 0)          pl.x = 0;
  if (pl.x + pl.w > W)   pl.x = W - pl.w;

  // Platform collisions & trap updates
  const now = Date.now();
  lv.platforms.forEach(p => {

    // ── Vanish trap ──────────────────────────────────────────────────────────
    if (p.type === 'vanish') {
      if (!p.gone && !p.warnPhase) {
        if (!p._start) p._start = now;
        const timeLeft = p.vanishDelay - (now - p._start);
        if (timeLeft < 900) {
          p.warnPhase     = true;
          p.warnCountdown = timeLeft;
          showWarn('PLATFORM VANISHING!');
        }
      }
      if (p.warnPhase && !p.gone) {
        p.warnCountdown -= 16.67 * dt;
        if (p.warnCountdown <= 0) {
          p.gone    = true;
          p.hidden  = true;
          p.respawn = now + 3000;
          hideWarn();
        }
      }
      if (p.gone && now > p.respawn) {
        p.gone          = false;
        p.hidden        = false;
        p.warnPhase     = false;
        p.warnCountdown = 0;
        p._start        = now + 1500;
      }
    }

    if (p.hidden || p.gone) return;

    // ── Collision ─────────────────────────────────────────────────────────────
    if (pl.vy >= 0 && colRect(pl.x, pl.y, pl.w, pl.h, p.x, p.y, p.w, p.h)) {
      const wasAbove = pl.y + pl.h - pl.vy * dt <= p.y + 6;
      if (wasAbove) {
        if (p.type === 'spike')  { die('#ef4444'); return; }
        if (p.type === 'fake')   { die('#06b6d4'); return; }

        if (p.type === 'hot') {
          if (!p._hotTimer) p._hotTimer = 0;
          p._hotTimer += 16.67 * dt;
          if (p._hotTimer > 600) { p._hotTimer = 0; die('#f97316'); return; }
        } else {
          p._hotTimer = 0;
        }

        if (p.type === 'ice')    { pl.vx += pl.vx >= 0 ? 0.5 : -0.5; }
        if (p.type === 'bounce') { pl.vy = JSPD * 1.55; return; }

        pl.y   = p.y - pl.h;
        pl.vy  = 0;
        pl.onG = true;
      }
    } else {
      p._hotTimer = 0;
    }
  });

  // Goal check
  if (colRect(pl.x, pl.y, pl.w, pl.h, lv.goal.x - 15, lv.goal.y - 15, 30, 30)) {
    spawnParticles(lv.goal.x, lv.goal.y, '#fbbf24', 20);
    if (lvIdx < allLevels.length - 1) {
      showMsg('Level clear! ROAR!', 1800);
      gameState = 'win';
      setTimeout(() => { lvIdx++; resetLevel(lvIdx); }, 1800);
    } else {
      showMsg('You conquered Glitch Grove! The lion reigns!', 5000);
      gameState = 'win';
    }
  }

  // Fall off screen
  if (pl.y > H + 80) die('#a855f7');
}

// ─── Render ──────────────────────────────────────────────────────────────────
function render() {
  ctx.clearRect(0, 0, W, H);
  drawBg();
  drawGround();

  lv.platforms.forEach(p => drawPlatform(ctx, p));
  drawGoal(lv.goal);
  drawParticles(ctx);

  if (!pl.dead || pl.alpha > 0) {
    drawLion(ctx, pl.x, pl.y, pl.w, pl.h, pl.alpha, pl.dead, facing, pl.onG, pl.vx);
  }

  if (screenFlash > 0) {
    ctx.globalAlpha = screenFlash * 0.35;
    ctx.fillStyle   = screenFlashColor;
    ctx.fillRect(0, 0, W, H);
    ctx.globalAlpha = 1;
  }

  drawLegend(ctx);
}

// ─── Main Loop ───────────────────────────────────────────────────────────────
let lastT = 0;
function loop(ts) {
  const dt = Math.min((ts - lastT) / 16.67, 3);
  lastT = ts;

  update(dt);
  updateParticles(dt);

  if (warnTimerLeft > 0) {
    warnTimerLeft -= 16.67 * dt;
    if (warnTimerLeft <= 0) hideWarn();
  }

  render();
  requestAnimationFrame(loop);
}

// ─── Input ───────────────────────────────────────────────────────────────────
document.addEventListener('keydown', e => {
  if (e.key === 'ArrowLeft'  || e.key === 'a') keys.left  = true;
  if (e.key === 'ArrowRight' || e.key === 'd') keys.right = true;
  if (e.key === ' ' || e.key === 'ArrowUp' || e.key === 'w') {
    keys.jump = true;
    e.preventDefault();
  }
});
document.addEventListener('keyup', e => {
  if (e.key === 'ArrowLeft'  || e.key === 'a') keys.left  = false;
  if (e.key === 'ArrowRight' || e.key === 'd') keys.right = false;
  if (e.key === ' ' || e.key === 'ArrowUp' || e.key === 'w') keys.jump = false;
});

function bindBtn(id, key) {
  const el = document.getElementById(id);
  el.addEventListener('pointerdown',  e => { e.preventDefault(); keys[key] = true;  });
  el.addEventListener('pointerup',    e => { e.preventDefault(); keys[key] = false; });
  el.addEventListener('pointerleave', ()  => { keys[key] = false; });
}
bindBtn('arrL', 'left');
bindBtn('arrR', 'right');
bindBtn('arrJ', 'jump');

// ─── Start ───────────────────────────────────────────────────────────────────
resetLevel(0);
requestAnimationFrame(loop);
