// js/lion.js
// Draws the lion player character on a canvas context

/**
 * drawLion(ctx, x, y, w, h, alpha, isDead, facingDir, isOnGround, velX)
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} x        - top-left x of the lion's bounding box
 * @param {number} y        - top-left y of the lion's bounding box
 * @param {number} w        - width of bounding box
 * @param {number} h        - height of bounding box
 * @param {number} alpha    - opacity (0–1)
 * @param {boolean} isDead  - skip tail wag when dead
 * @param {number} facingDir - 1 = right, -1 = left
 * @param {boolean} isOnGround
 * @param {number} velX     - horizontal velocity (used for leg animation)
 */
function drawLion(ctx, x, y, w, h, alpha, isDead, facingDir, isOnGround, velX) {
  ctx.save();
  ctx.globalAlpha = alpha;

  const cx = x + w / 2;
  const cy = y + h / 2;
  const t  = Date.now() / 160;
  const bob = isOnGround && !isDead ? Math.sin(t) * 1.2 : 0;

  ctx.translate(cx, cy + bob);
  if (facingDir < 0) ctx.scale(-1, 1);

  const R = w / 2 + 1;

  // --- Mane (drawn behind body) ---
  const maneSpikes = 12;
  for (let i = 0; i < maneSpikes; i++) {
    const ang    = (i / maneSpikes) * Math.PI * 2;
    const innerR = R + 1;
    const outerR = R + 9 + Math.sin(ang * 3 + t * 0.3) * 2;
    const x1 = Math.cos(ang) * innerR;
    const y1 = Math.sin(ang) * innerR;
    const x2 = Math.cos(ang) * outerR;
    const y2 = Math.sin(ang) * outerR;
    const midAng = ang + Math.PI / maneSpikes;
    const xm = Math.cos(midAng) * (innerR + 2);
    const ym = Math.sin(midAng) * (innerR + 2);
    ctx.fillStyle = '#c97c10';
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.lineTo(xm, ym);
    ctx.closePath();
    ctx.fill();
  }

  // Mane base ring
  ctx.fillStyle = '#f5a623';
  ctx.beginPath(); ctx.arc(0, 0, R + 2, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#c97c10';
  ctx.beginPath(); ctx.arc(0, 0, R + 1, 0, Math.PI * 2); ctx.fill();

  // --- Body / Head ---
  ctx.fillStyle = '#e8a93a';
  ctx.beginPath(); ctx.arc(0, 0, R, 0, Math.PI * 2); ctx.fill();

  // Snout
  ctx.fillStyle = '#f5c060';
  ctx.beginPath(); ctx.ellipse(R * 0.45, R * 0.15, R * 0.42, R * 0.32, 0, 0, Math.PI * 2); ctx.fill();

  // Nose
  ctx.fillStyle = '#8b3a1a';
  ctx.beginPath(); ctx.ellipse(R * 0.72, R * 0.05, R * 0.13, R * 0.09, 0, 0, Math.PI * 2); ctx.fill();

  // Nostrils
  ctx.fillStyle = '#5a1f08';
  ctx.beginPath(); ctx.ellipse(R * 0.66, R * 0.10, R * 0.04, R * 0.03,  0.3, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.ellipse(R * 0.78, R * 0.10, R * 0.04, R * 0.03, -0.3, 0, Math.PI * 2); ctx.fill();

  // Mouth lines
  ctx.strokeStyle = '#8b3a1a'; ctx.lineWidth = 1.5; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(R * 0.72, R * 0.15); ctx.lineTo(R * 0.60, R * 0.30); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(R * 0.72, R * 0.15); ctx.lineTo(R * 0.85, R * 0.30); ctx.stroke();

  // Chin tuft
  ctx.fillStyle = '#f0d080';
  ctx.beginPath(); ctx.ellipse(R * 0.72, R * 0.42, R * 0.18, R * 0.12, 0, 0, Math.PI * 2); ctx.fill();

  // --- Eyes ---
  const eyeY = -R * 0.22;
  // Whites
  ctx.fillStyle = '#fff';
  ctx.beginPath(); ctx.ellipse(-R * 0.18, eyeY, R * 0.16, R * 0.13, 0, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.ellipse( R * 0.25, eyeY, R * 0.16, R * 0.13, 0, 0, Math.PI * 2); ctx.fill();
  // Irises
  ctx.fillStyle = '#d4870a';
  ctx.beginPath(); ctx.ellipse(-R * 0.18, eyeY, R * 0.10, R * 0.11, 0, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.ellipse( R * 0.25, eyeY, R * 0.10, R * 0.11, 0, 0, Math.PI * 2); ctx.fill();
  // Pupils
  ctx.fillStyle = '#1a0a00';
  ctx.beginPath(); ctx.ellipse(-R * 0.18, eyeY, R * 0.05, R * 0.09, 0, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.ellipse( R * 0.25, eyeY, R * 0.05, R * 0.09, 0, 0, Math.PI * 2); ctx.fill();
  // Glints
  ctx.fillStyle = 'rgba(255,255,255,0.85)';
  ctx.beginPath(); ctx.arc(-R * 0.14, eyeY - R * 0.04, R * 0.03, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc( R * 0.29, eyeY - R * 0.04, R * 0.03, 0, Math.PI * 2); ctx.fill();

  // --- Ears ---
  ctx.fillStyle = '#c97c10';
  ctx.beginPath(); ctx.moveTo(-R*0.55,-R*0.72); ctx.lineTo(-R*0.82,-R*1.18); ctx.lineTo(-R*0.22,-R*0.75); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo( R*0.28,-R*0.72); ctx.lineTo( R*0.62,-R*1.18); ctx.lineTo( R*0.65,-R*0.68); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#f5a0a0';
  ctx.beginPath(); ctx.moveTo(-R*0.55,-R*0.76); ctx.lineTo(-R*0.76,-R*1.10); ctx.lineTo(-R*0.26,-R*0.78); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo( R*0.32,-R*0.75); ctx.lineTo( R*0.58,-R*1.10); ctx.lineTo( R*0.60,-R*0.72); ctx.closePath(); ctx.fill();

  // --- Tail ---
  if (!isDead) {
    const tailWag = Math.sin(t * 1.8) * 18;
    ctx.strokeStyle = '#c97c10'; ctx.lineWidth = 4; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(-R, 0);
    ctx.quadraticCurveTo(-R - 14, R * 0.5 + tailWag, -R - 20, R * 0.8 + tailWag);
    ctx.stroke();
    ctx.fillStyle = '#f5c060';
    ctx.beginPath(); ctx.arc(-R - 20, R * 0.8 + tailWag, 5, 0, Math.PI * 2); ctx.fill();
  }

  // --- Running legs ---
  if (isOnGround && Math.abs(velX) > 0.5) {
    const step = Math.sin(t * 4) * 5;
    ctx.fillStyle = '#c97c10';
    ctx.beginPath(); ctx.ellipse(-R * 0.3, R + step,  R * 0.2, R * 0.14, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse( R * 0.3, R - step, R * 0.2, R * 0.14, 0, 0, Math.PI * 2); ctx.fill();
  }

  ctx.restore();
}
