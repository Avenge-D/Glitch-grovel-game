// js/levels.js
// All 5 level definitions for Glitch Grove

function buildLevels() {
  const GY = 330;
  const lvs = [
    {
      groundY: GY,
      goal: { x: 635, y: GY - 22 },
      msg: 'Roar! Find the star, lion!',
      platforms: [
        { x: 130, y: 260, w: 90,  h: 14, type: 'normal' },
        { x: 280, y: 210, w: 80,  h: 14, type: 'vanish', vanishDelay: 3500, warnCountdown: 0, warnPhase: false, gone: false, respawn: 0 },
        { x: 420, y: 255, w: 100, h: 14, type: 'normal' },
        { x: 555, y: 210, w: 90,  h: 14, type: 'normal' },
      ],
    },
    {
      groundY: GY,
      goal: { x: 625, y: GY - 22 },
      msg: 'Ice is slippery. Spikes bite.',
      platforms: [
        { x: 110, y: 265, w: 80, h: 14, type: 'ice' },
        { x: 250, y: 220, w: 75, h: 14, type: 'spike' },
        { x: 370, y: 265, w: 85, h: 14, type: 'ice' },
        { x: 500, y: 215, w: 80, h: 14, type: 'normal' },
        { x: 590, y: 265, w: 70, h: 14, type: 'normal' },
      ],
    },
    {
      groundY: GY,
      goal: { x: 620, y: GY - 22 },
      msg: 'Bounce pads send you flying!',
      platforms: [
        { x: 120, y: 260, w: 85, h: 14, type: 'bounce' },
        { x: 260, y: 200, w: 70, h: 14, type: 'normal' },
        { x: 370, y: 250, w: 80, h: 14, type: 'bounce' },
        { x: 500, y: 195, w: 90, h: 14, type: 'vanish', vanishDelay: 2800, warnCountdown: 0, warnPhase: false, gone: false, respawn: 0 },
        { x: 570, y: 250, w: 70, h: 14, type: 'normal' },
      ],
    },
    {
      groundY: GY,
      goal: { x: 610, y: GY - 22 },
      msg: 'Hot floors. Fake floors. Good luck.',
      platforms: [
        { x: 110, y: 260, w: 80, h: 14, type: 'hot' },
        { x: 250, y: 210, w: 75, h: 14, type: 'fake' },
        { x: 360, y: 260, w: 80, h: 14, type: 'normal' },
        { x: 470, y: 205, w: 70, h: 14, type: 'hot' },
        { x: 565, y: 255, w: 85, h: 14, type: 'normal' },
      ],
    },
    {
      groundY: GY,
      goal: { x: 628, y: GY - 22 },
      msg: 'The Grove knows you now. Roar back.',
      platforms: [
        { x: 100, y: 265, w: 75, h: 14, type: 'ice' },
        { x: 220, y: 210, w: 70, h: 14, type: 'spike' },
        { x: 330, y: 260, w: 80, h: 14, type: 'bounce' },
        { x: 440, y: 205, w: 70, h: 14, type: 'vanish', vanishDelay: 2200, warnCountdown: 0, warnPhase: false, gone: false, respawn: 0 },
        { x: 530, y: 255, w: 75, h: 14, type: 'hot' },
        { x: 600, y: 205, w: 70, h: 14, type: 'normal' },
      ],
    },
  ];
  // Deep clone so resets are clean
  return JSON.parse(JSON.stringify(lvs));
}
