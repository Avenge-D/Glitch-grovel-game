// js/platforms.js
// Platform rendering and collision helpers

const PLATFORM_COLORS = {
  normal: ['#7c3aed', '#a855f7'],
  spike:  ['#dc2626', '#ef4444'],
  fake:   ['#0891b2', '#06b6d4'],
  ice:    ['#0369a1', '#38bdf8'],
  bounce: ['#d97706', '#fbbf24'],
  vanish: ['#065f46', '#10b981'],
  hot:    ['#9a3412', '#f97316'],
};

const LEGEND = [
  { color: '#7c3aed', label: 'Safe'   },
  { color: '#dc2626', label: 'Spikes' },
  { color: '#0891b2', label: 'Fake'   },
  { color: '#0369a1', label: 'Ice'    },
  { color: '#d97706', label: 'Bounce' },
  { color: '#065f46', label: 'Vanish' },
  { color: '#9a3412', label: 'Hot'    },
];

/**
 * drawPlatform(ctx, p)
 * Renders a single platform object.
 */
function drawPlatform(ctx, p) {
  if (p.hidden) return;

  ctx.save();
  ctx.globalAlpha = p.fadeAlpha !== undefined ? p.fadeAlpha : 1;

  const cx = p.x + p.w / 2;
  const cy = p.y + p.h / 2;
  ctx.translate(cx, cy);
  if (p.rot) ctx.rotate(p.rot);
  ctx.translate(-p.w / 2, -p.h / 2);

  const c = PLATFORM_COLORS[p.type] || PLATFORM_COLORS.normal;

  // Base
  ctx.fillStyle = c[0];
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(0, 0, p.w, p.h, 5);
  else ctx.rect(0, 0, p.w, p.h);
  ctx.fill();

  // Highlight strip
  ctx.fillStyle = c[1];
  ctx.fillRect(4, 3, p.w - 8, 4);

  // Type-specific decorations
  if (p.type === 'spike') {
    ctx.fillStyle = '#fca5a5';
    for (let sx = 4; sx < p.w - 4; sx += 12) {
      ctx.beginPath();
      ctx.moveTo(sx, 0); ctx.lineTo(sx + 6, -12); ctx.lineTo(sx + 12, 0);
      ctx.fill();
    }
  }

  if (p.type === 'bounce') {
    ctx.fillStyle = '#fef3c7';
    ctx.beginPath(); ctx.arc(p.w / 2, -6, 5, 0, Math.PI * 2); ctx.fill();
  }

  if (p.type === 'ice') {
    ctx.fillStyle = 'rgba(186,230,253,0.6)';
    ctx.fillRect(4, 3, p.w - 8, p.h - 6);
    ctx.fillStyle = '#bae6fd';
    for (let ix = 8; ix < p.w - 4; ix += 16) ctx.fillRect(ix, 4, 6, 2);
  }

  if (p.type === 'hot') {
    const tt = Date.now() / 200;
    ctx.fillStyle = '#fde68a';
    for (let fx = 6; fx < p.w - 4; fx += 14) {
      const fh = 4 + Math.sin(tt + fx) * 3;
      ctx.fillRect(fx, -fh, 4, fh);
    }
  }

  if (p.type === 'vanish' && p.warnPhase) {
    ctx.strokeStyle = '#34d399'; ctx.lineWidth = 2;
    ctx.setLineDash([4, 4]);
    ctx.strokeRect(1, 1, p.w - 2, p.h - 2);
    ctx.setLineDash([]);
  }

  ctx.restore();

  // Warning bubble above vanish platforms
  if (p.warnCountdown > 0 && p.warnCountdown < 800) {
    const prog = p.warnCountdown / 800;
    ctx.fillStyle = `rgba(255,60,60,${prog * 0.85})`;
    ctx.beginPath(); ctx.arc(p.x + p.w / 2, p.y - 18, 7, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('!', p.x + p.w / 2, p.y - 18);
  }
}

/**
 * drawLegend(ctx)
 * Draws the platform type legend in the top-left corner.
 */
function drawLegend(ctx) {
  let lx = 8;
  LEGEND.forEach(li => {
    ctx.fillStyle = li.color;
    ctx.fillRect(lx, 8, 8, 8);
    ctx.fillStyle = 'rgba(255,255,255,0.75)';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(li.label, lx + 11, 12);
    lx += ctx.measureText(li.label).width + 22;
  });
}

/**
 * colRect(ax,ay,aw,ah, bx,by,bw,bh) → boolean
 * Simple AABB collision check.
 */
function colRect(ax, ay, aw, ah, bx, by, bw, bh) {
  return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
}
